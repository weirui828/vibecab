# @wei/design-system

A dashboard design system with **five themes** in two families — three from
Pantone Colors of the Year (Snorkel Blue 2020, Cloud Dancer 2026, Grand Canyon
2017) and two field palettes (an editorial Microbrew and an Icelandic Tundra) —
switchable at runtime, each with light and dark modes.

React 19 · TypeScript · Tailwind v4 · 37 components · 8 kB gzipped

---

## The idea

**Snorkel Blue** (default) is a bold tropical palette in which *classic black and
white create the drama* against the depth of Classic Blue: a crisp achromatic
ground that stays out of the way, a deep saturated accent (`#0f4c81`) carrying
every interactive element, and the tropical hues — lagoon, reef, palm, sun —
held back for status and data rather than chrome.

**Cloud Dancer** is its opposite: Light & Shadow is tonal, softened hues
dissolving into shadowy shades, so nothing in the neutral range competes for
attention. The page itself is Cloud Dancer (`#f0eee9`) and cards lift *toward*
the light rather than sitting on white. Its accent is a veiled teal-slate
(`#4a6b6b`) — enough colour to mark interactive elements, restrained enough to
stay inside the mood.

**Grand Canyon** pairs PANTONE 15-0343 Greenery with the desert hues of its
Grand Canyon companion palette: warm stone ground, canyon rust (`#a65028`) on
every interactive element. Greenery itself (`#88b04b`) cannot carry interaction
— white on it is ~2.4:1, far below AA — so it lives where it works, as success
and as the `sage` ramp.

**Microbrew** is the odd one out — not a Pantone palette but an editorial one,
sampled from typewolf.com/lookbooks: a dusty mauve field (`#e6ddde`), white
cards, deep plum text (`#443235`), and a muted olive primary (`#79875e`) taken
from the Outdoorsy Microbrew lookbook cover. Info borrows the SaaS Tech cover's
cobalt. Quiet and print-adjacent, with one earthy accent.

**Tundra** is the other field palette: Icelandic tundra, grey-green moss over
black basalt. A cottongrass page (`#f3f1ea`), cards a tone *darker* and drawn
with hairlines rather than shadows, and a deep moss primary (`#4c5d3f`); the
moss itself (`#7f8f6a`) names the theme but is too light to carry text. Glacier
meltwater, golden sedge and autumn rust are kept for status and data. Success
is a cooler juniper green so it never reads as the primary.

All five ship in the same stylesheet. Switching is one attribute.

### Themes

| `data-theme` | Theme |
|---|---|
| *(omitted)* or `snorkel-blue` | Snorkel Blue |
| `cloud-dancer` | Cloud Dancer / Light & Shadow |
| `grand-canyon` | Grand Canyon / Greenery |
| `microbrew` | Editorial mauve & olive |
| `tundra` | Icelandic moss on basalt |

`data-theme` and `.dark` are orthogonal — ten states in total. Put both on the
same element:

```html
<html data-theme="cloud-dancer" class="dark">
```

---

## Install

```bash
npm install @wei/design-system
```

### If your app uses Tailwind v4 (recommended)

Import the theme and point Tailwind at the library so it generates the
utilities the components use:

```css
/* app.css */
@import "tailwindcss";
@import "@wei/design-system/theme.css";

@source "../node_modules/@wei/design-system/dist";
```

You now share the design system's vocabulary — `bg-surface-raised`,
`text-fg-muted`, `gap-md` — in your own markup.

### If your app does not use Tailwind

Import the prebuilt stylesheet instead. Besides everything the components need,
it deliberately ships the layout vocabulary — grid, flex, the named spacing
scale, semantic colours, type, radius, elevation — so you can compose *around*
the components without running Tailwind:

```ts
import "@wei/design-system/styles.css";
```

---

## Usage

```tsx
import { Card, CardHeader, CardTitle, StatTile, Button, Stack } from "@wei/design-system";

export function Dashboard() {
  return (
    <Stack gap="lg">
      <StatTile
        label="Monthly recurring revenue"
        value="$48,290"
        delta="12.4%"
        direction="up"
        sentiment="positive-up"
        caption="vs. last month"
      />
      <Card>
        <CardHeader actions={<Button size="sm">Export</Button>}>
          <CardTitle>Recent activity</CardTitle>
        </CardHeader>
      </Card>
    </Stack>
  );
}
```

### Theme and dark mode

Both remap only the semantic layer — components are untouched, and no component
in the library knows a theme exists:

```tsx
<div data-theme={theme} className={isDark ? "dark" : undefined}>…</div>
```

---

## Token architecture

Two layers, and the split is the whole point:

| Layer | Examples | Who uses it |
|---|---|---|
| **Palette** — raw, fixed | `--color-ink-*`/`--color-classic-*` (Snorkel Blue); `--color-cloud-*`/`--color-teal-*` (Cloud Dancer); `--color-stone-*`/`--color-canyon-*`/`--color-sage-*` (Grand Canyon); `--color-mauve-*`/`--color-olive-*` (Microbrew); `--color-basalt-*`/`--color-tundra-*` (Tundra) | the theme only |
| **Semantic** — intent | `--color-surface-raised`, `--color-fg-muted`, `--color-accent-default` | every component |

Components reference **only** the semantic layer. That is why dark mode costs
nothing (remap semantics, leave components alone) and why retheming is a matter
of editing token values rather than touching source.

### Where the tokens live

`src/styles/theme.css` holds the fonts, the default semantic tokens and the
shared scales; each theme is one file in `src/styles/themes/` (palette ramps,
light and dark blocks, type pairing). The build inlines them, so the published
`theme.css` is still a single file.

### Adding or overriding a theme

Target the theme you mean, not `:root` — the shipped `[data-theme=…]` blocks
have the same specificity as `:root` and come later, so a `:root` override
loses:

```css
@import "@wei/design-system/theme.css";

@layer theme {
  /* tweak a shipped theme */
  [data-theme="snorkel-blue"] {
    --color-accent-default: #7c3aed;
    --color-accent-hover:   #6d28d9;
  }

  /* or add your own */
  [data-theme="acme"]      { /* …semantic tokens, light… */ }
  [data-theme="acme"].dark { /* …semantic tokens, dark…  */ }
}
```

You only need the ~30 semantic tokens; spacing, type and radius are shared
across themes on purpose, so swapping palettes never reflows the layout.

Then re-run `npm run audit:contrast` — a new accent can quietly fall below
contrast targets. To have the audit cover your theme, add an `@audit <name>
<mode>` marker comment above each block and one entry to the `THEMES` list in
`scripts/audit-contrast.mjs`.

### Border tokens — read before using

`border-subtle` / `default` / `strong` are **decorative** (card outlines,
dividers, table rules) and deliberately soft. `border-control` is for
**interactive** boundaries — inputs, selects, checkboxes, outlined buttons —
and is the lightest step clearing WCAG 1.4.11's 3:1 against every surface.
Don't substitute one for the other.

---

## Components

| Group | Components |
|---|---|
| Actions | `Button` `IconButton` |
| Layout | `Stack` `Inline` `Card` (+ `Header` `Title` `Description` `Body` `Footer`) `Divider` |
| Forms | `Field` `Input` `Textarea` `Select` `Checkbox` `Switch` `Radio` `RadioGroup` |
| Data | `Badge` `Avatar` `StatTile` `Table` (+ `Head` `Body` `Row` `HeaderCell` `Cell` `Caption`) |
| Feedback | `Alert` `Spinner` `Skeleton` `Progress` |
| Navigation | `Tabs` `TabList` `Tab` `TabPanel` |
| Media | `Icon` |
| Website | `SiteHeader` `SiteMain` `SiteSection` `Hero` (+ `HeroFact`) `ProjectCard` `Timeline` (+ `TimelineItem`) `ContactPanel` `SiteFooter` |

Every component exports its props as `<Name>Props`.

### `Field` wires accessibility for you

A control inside a `Field` inherits its `id`, `aria-describedby`,
`aria-invalid`, `required` and `disabled` automatically — the label points at
the right element and the hint or error is announced, with no manual id
plumbing:

```tsx
<Field label="Billing email" error="Enter a valid email address." required>
  <Input defaultValue="billing@" />
</Field>
```

### `StatTile` colours by meaning, not direction

`sentiment` says whether *up* is good. Revenue rising is green; churn rising is
red; headcount rising is neutral. The arrow reports what moved, the colour
reports whether to worry.

```tsx
<StatTile label="Churn rate" value="2.8%" delta="0.6pp"
          direction="up" sentiment="positive-down" />  {/* renders red */}
```

---

## Accessibility

- **Contrast is enforced, not assumed.** `npm run audit:contrast` parses
  `theme.css` and its per-theme files directly and checks 380 pairs — 38 per
  theme × mode combination —
  against WCAG 1.4.3 and 1.4.11. It exits non-zero on failure, so a theme
  cannot ship below target. Run it after any token change.
- **One focus indicator**, `outline`-based so it follows border-radius,
  survives `overflow-hidden`, and persists in Windows High Contrast Mode.
- `Tabs` implements the WAI-ARIA APG tab pattern: roving tabindex, arrow keys,
  Home/End, wrapping.
- Motion respects `prefers-reduced-motion`.
- `IconButton` requires `label` at the type level — an icon-only button cannot
  be built without an accessible name.

---

## Scripts

| Script | Does |
|---|---|
| `npm run build` | Build `dist/` — ESM, types, and both stylesheets |
| `npm run demo` | Dashboard demo at `localhost:5199`, consuming `dist/` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run audit:contrast` | WCAG audit of the token layer |

`npm run demo` imports from `dist/`, not `src/`, on purpose — it verifies what
consumers actually install. Run `npm run build` first.

---

## Type

Every size is even and on the 4px grid, in `rem` (1rem = 16px at the browser
default, so text follows the reader's font-size setting).

**Dashboard scale**: `text-xs` 12/16 (labels, badges, table headers), `text-sm`
16/24 (UI and body), `text-lg` 20/28 (card titles), `text-2xl` 28/36 (stat
values, page titles). Nothing else exists: Tailwind's default text and radius
scales are reset, so `text-base`, `text-xl` or `rounded-2xl` produce nothing.

**Website scale** for portfolio and marketing pages: `text-site-display` 64,
`h1` 48, `h2` 32, `h3` 24, `lead` 20, `body` 16, `small` 12. Display, h1 and
h2 step down below 640px. Headings get the theme's display face; wrap prose in
`site-prose` to cap it at `--measure-site` (64ch).

**Pairings** (from Typewolf's free Google Fonts list), set per theme:

| Theme | UI (`font-sans`) | Display (`font-display`) | Mono (`font-mono`) |
|---|---|---|---|
| Snorkel Blue | IBM Plex Sans | Space Grotesk | Space Mono |
| Cloud Dancer | Karla | Cormorant | Inconsolata |
| Grand Canyon | Work Sans | Alegreya | Inconsolata |
| Microbrew | DM Sans | Fraunces | Space Mono |
| Tundra | Instrument Sans | Fraunces | JetBrains Mono |

## Status colours

Success, warning, danger and info are anchored on real Pantone TCX colours in
every theme, and info is its own hue rather than a copy of the accent. Each
status has `subtle`, `default`, `fg` and a `border` token (`border-success-border`
and friends), which `Alert` uses for its outline. `fg-subtle` is folded into
`fg-muted` and kept only as an alias.

## Chart colours

Six categorical series per theme and mode, `chart-1` to `chart-6`
(`bg-chart-1`, `fill-chart-1`, `stroke-chart-1`, `--color-chart-1`). They are
built from the palette ramps no semantic token used (lagoon, rose, blush,
cobalt, pine and others) so charts never borrow status colours. Every series
clears 3:1 against the page and cards (WCAG 1.4.11), and odd and even series
alternate dark and light, so neighbouring series differ in lightness and stay
apart for colour-blind readers. Use them in order; past six series, group the
rest as "Other" in `fg-muted`. Still label series directly or with a legend:
colour alone never carries the meaning.

## Motion

| Token | Value | Use |
|---|---|---|
| `--duration-fast` | 120ms | hover, focus, colour changes (the default for every `transition-*`) |
| `--duration-base` | 200ms | toggles, tabs, small movement |
| `--duration-slow` | 320ms | panels, dialogs, progress |
| `--ease-standard` | `cubic-bezier(0.2, 0, 0, 1)` | most transitions (the default) |
| `--ease-emphasized` | `cubic-bezier(0.3, 0, 0, 1.15)` | elements entering, with a small overshoot |

Utilities: `duration-fast`, `duration-base`, `duration-slow`, `ease-standard`,
`ease-emphasized`. With `prefers-reduced-motion: reduce` all three durations
become 0ms, so nothing animates; never make meaning depend on movement.

## Icons

`<Icon name="arrow-right" />` draws any of them inline in `currentColor`, at
16 (default), 20 or 24px; `name` autocompletes. Give `label` only when the icon
carries meaning alone. After adding an SVG to `assets/icons`, run
`npm run icons` to regenerate `src/components/icons.generated.ts`.

`assets/icons` ships 49 Heroicons (outline, 24px, MIT) and 25 brand logos from
Simple Icons (CC0), including WeChat, Xiaohongshu, Zhihu and Bilibili. Import
them as `@wei/design-system/icons/heroicons/<name>.svg` or
`@wei/design-system/icons/brands/<name>.svg`. Brand logos remain their owners'
trademarks; see `assets/icons/LICENSE.txt`.

## Website components

For a portfolio or marketing site: `SiteHeader`, `SiteMain`, `SiteSection`,
`Hero` with `HeroFact`, `ProjectCard`, `Timeline` with `TimelineItem`,
`ContactPanel` and `SiteFooter`. They use the website type scale and the same
semantic tokens as everything else, so a theme switch restyles the whole site.
`ContactPanel` renders in the theme's dark mode through a nested `.dark`, so it
stands out on a light page with no special colours.

```tsx
<SiteHeader brand="Wei Rui" links={[{ label: 'Work', href: '#work' }]} />
<SiteMain>
  <Hero title="Wei Rui" lead="ML/AI engineer." />
  <SiteSection id="work" title="Selected work">
    <ProjectCard kicker="01 · Framework" title="An eval framework" href="/work/evals">…</ProjectCard>
  </SiteSection>
  <ContactPanel title="Let's talk" actions={<Button variant="primary">Email me</Button>} />
</SiteMain>
<SiteFooter>© Wei Rui</SiteFooter>
```

---

## Notes

- React is a peer dependency; `clsx` and `tailwind-merge` are external. Nothing
  is bundled that npm can install, so consumers never get a second copy of React.
- `cn()` is exported. It merges classes so later Tailwind utilities win, which
  makes every `className` prop a real override rather than a specificity fight.
- Fonts are self-hosted woff2 files (SIL OFL 1.1, licences in
  `src/styles/fonts/licenses`). The build copies them to `dist/fonts`, next to
  both stylesheets, so the relative `url()`s resolve. Change `--font-sans`,
  `--font-display` and `--font-mono` to rebrand.
